<form method="post" class="card" novalidate>
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="version" value="<?= (int) $version ?>">

  <label>Инвентарный номер
    <input name="inventory" value="<?= e($data['inventory']) ?>" maxlength="20" required>
    <?php if (isset($errors['inventory'])): ?><span class="field-err"><?= e($errors['inventory']) ?></span><?php endif; ?>
  </label>

  <label>Тип
    <select name="type">
      <?php foreach (EQUIPMENT_TYPES as $k => $label): ?>
        <option value="<?= e($k) ?>" <?= $data['type'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
    <?php if (isset($errors['type'])): ?><span class="field-err"><?= e($errors['type']) ?></span><?php endif; ?>
  </label>

  <label>Аудитория
    <input name="room" value="<?= e($data['room']) ?>" maxlength="20" required>
    <?php if (isset($errors['room'])): ?><span class="field-err"><?= e($errors['room']) ?></span><?php endif; ?>
  </label>

  <label>Состояние
    <select name="status">
      <?php foreach (EQUIPMENT_STATUSES as $k => $label): ?>
        <option value="<?= e($k) ?>" <?= $data['status'] === $k ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
    <?php if (isset($errors['status'])): ?><span class="field-err"><?= e($errors['status']) ?></span><?php endif; ?>
  </label>

  <label>Примечание
    <textarea name="note" rows="3" maxlength="400"><?= e($data['note']) ?></textarea>
    <?php if (isset($errors['note'])): ?><span class="field-err"><?= e($errors['note']) ?></span><?php endif; ?>
  </label>

  <button type="submit">Сохранить</button>
  <a href="index.php">Отмена</a>
</form>

<?php if ($history !== []): ?>
  <h2>Журнал перемещений и изменений</h2>
  <ul class="history">
    <?php foreach (array_reverse($history) as $h): ?>
      <li><span class="muted"><?= e($h['at'] ?? '') ?></span> — <?= e($h['event'] ?? '') ?></li>
    <?php endforeach; ?>
  </ul>
<?php endif; ?>
