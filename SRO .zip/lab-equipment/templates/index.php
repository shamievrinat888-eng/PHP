<?php if ($error !== null): ?>
  <div class="flash err"><?= e($error) ?></div>
<?php else: ?>
<form method="get" class="filters">
  <input type="search" name="q" value="<?= e($q) ?>" placeholder="Номер, аудитория, примечание" maxlength="50">
  <select name="type">
    <option value="">Все типы</option>
    <?php foreach (EQUIPMENT_TYPES as $k => $label): ?>
      <option value="<?= e($k) ?>" <?= $type === $k ? 'selected' : '' ?>><?= e($label) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="status">
    <option value="">Все состояния</option>
    <?php foreach (EQUIPMENT_STATUSES as $k => $label): ?>
      <option value="<?= e($k) ?>" <?= $status === $k ? 'selected' : '' ?>><?= e($label) ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit">Найти</button>
  <a href="index.php">Сбросить</a>
</form>

<p class="muted">Всего: <?= (int) $summary['total'] ?>.
  <?php foreach (EQUIPMENT_STATUSES as $k => $label): ?>
    <span class="badge s-<?= e($k) ?>"><?= e($label) ?>: <?= (int) $summary['by_status'][$k] ?></span>
  <?php endforeach; ?>
</p>

<?php if ($items === []): ?>
  <p>Ничего не найдено.</p>
<?php else: ?>
<table>
  <thead><tr><th>Инв. номер</th><th>Тип</th><th>Аудитория</th><th>Состояние</th><th>Примечание</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($items as $it): ?>
    <tr>
      <td><?= e($it['inventory']) ?></td>
      <td><?= e(EQUIPMENT_TYPES[$it['type']] ?? $it['type']) ?></td>
      <td><?= e($it['room']) ?></td>
      <td><span class="badge s-<?= e($it['status']) ?>"><?= e(EQUIPMENT_STATUSES[$it['status']] ?? $it['status']) ?></span></td>
      <td><?= e($it['note']) ?></td>
      <td class="actions">
        <a href="edit.php?id=<?= e(rawurlencode((string) $it['id'])) ?>">Изменить</a>
        <form method="post" onsubmit="return confirm('Удалить запись?');">
          <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
          <input type="hidden" name="id" value="<?= e($it['id']) ?>">
          <button type="submit" class="danger">Удалить</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php endif; ?>
<?php endif; ?>
