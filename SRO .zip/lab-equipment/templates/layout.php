<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?> — Учёт оборудования</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
  <strong>Учёт оборудования лаборатории</strong>
  <nav>
    <a href="index.php">Реестр</a>
    <a href="edit.php">Добавить</a>
    <a href="summary.php">Сводка</a>
  </nav>
</header>
<main>
  <?php foreach (take_flashes() as $f): ?>
    <div class="flash <?= $f['type'] === 'success' ? 'ok' : 'err' ?>"><?= e($f['message']) ?></div>
  <?php endforeach; ?>
  <h1><?= e($title) ?></h1>
  <?= $content ?>
</main>
</body>
</html>
