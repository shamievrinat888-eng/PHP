<div class="flash err"><?= e($message) ?></div>
<p><a href="index.php">← К реестру</a></p>
