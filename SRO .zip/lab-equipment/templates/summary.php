<p>Всего единиц оборудования: <strong><?= (int) $summary['total'] ?></strong></p>
<div class="cols">
  <section>
    <h2>По состоянию</h2>
    <table><tbody>
    <?php foreach (EQUIPMENT_STATUSES as $k => $label): ?>
      <tr><td><span class="badge s-<?= e($k) ?>"><?= e($label) ?></span></td><td><?= (int) $summary['by_status'][$k] ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
  </section>
  <section>
    <h2>По типам</h2>
    <table><tbody>
    <?php foreach (EQUIPMENT_TYPES as $k => $label): ?>
      <tr><td><?= e($label) ?></td><td><?= (int) $summary['by_type'][$k] ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
  </section>
  <section>
    <h2>По аудиториям</h2>
    <table><tbody>
    <?php foreach ($summary['by_room'] as $room => $n): ?>
      <tr><td><?= e($room) ?></td><td><?= (int) $n ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
  </section>
</div>
<p><a href="index.php">← К реестру</a></p>
