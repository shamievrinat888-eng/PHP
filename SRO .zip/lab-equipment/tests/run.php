<?php
declare(strict_types=1);

// Запуск: php tests/run.php
$tmp = sys_get_temp_dir() . '/equip_test_' . bin2hex(random_bytes(4));
mkdir($tmp);
putenv('EQUIPMENT_DATA_FILE=' . $tmp . '/equipment.json');
require __DIR__ . '/../src/bootstrap.php';

$passed = 0; $failed = 0;
function check(string $name, bool $cond): void
{
    global $passed, $failed;
    if ($cond) { $passed++; echo "PASS  $name\n"; } else { $failed++; echo "FAIL  $name\n"; }
}
function valid(array $over = []): array
{
    return normalize_input($over + ['inventory' => 'pc-100', 'type' => 'computer', 'room' => '301', 'status' => 'working', 'note' => '']);
}

// T1 обычный сценарий
$d = valid(['inventory' => '  pc-100 ']);
check('T1 нормализация: регистр и пробелы', $d['inventory'] === 'PC-100');
check('T1 корректные данные без ошибок', validate_equipment($d) === []);

// T2 пустые значения
check('T2 пустой инв. номер', isset(validate_equipment(valid(['inventory' => '']))['inventory']));
check('T2 пустая аудитория', isset(validate_equipment(valid(['room' => '']))['room']));
$n = normalize_input([]);
check('T2 отсутствующие ключи -> ошибки', count(validate_equipment($n)) >= 4);

// T3 граничные значения
check('T3 номер 3 символа допустим', !isset(validate_equipment(valid(['inventory' => 'AB1']))['inventory']));
check('T3 номер 2 символа недопустим', isset(validate_equipment(valid(['inventory' => 'A1']))['inventory']));
check('T3 номер 20 символов допустим', !isset(validate_equipment(valid(['inventory' => str_repeat('A', 20)]))['inventory']));
check('T3 номер 21 символ недопустим', isset(validate_equipment(valid(['inventory' => str_repeat('A', 21)]))['inventory']));
check('T3 примечание 200 допустимо', !isset(validate_equipment(valid(['note' => str_repeat('я', 200)]))['note']));
check('T3 примечание 201 недопустимо', isset(validate_equipment(valid(['note' => str_repeat('я', 201)]))['note']));

// T4 некорректный тип
check('T4 массив вместо строки', isset(validate_equipment(valid(['inventory' => ['x']]))['inventory']));
check('T4 неизвестный тип', isset(validate_equipment(valid(['type' => 'toaster']))['type']));
check('T4 неизвестный статус', isset(validate_equipment(valid(['status' => 'lost']))['status']));
check('T4 спецсимволы в номере', isset(validate_equipment(valid(['inventory' => '<script>']))['inventory']));

// T5 хранилище: создание и уникальность
save_equipment(null, valid());
$all = load_equipment();
check('T5 запись создана', count($all) === 5); // 4 seed + 1
$dup = false;
try { save_equipment(null, valid()); } catch (ValidationException) { $dup = true; }
check('T5 дубликат инв. номера отклонён', $dup);

// T6 версия / конфликт и журнал
$rec = null;
foreach (load_equipment() as $it) { if ($it['inventory'] === 'PC-100') { $rec = $it; } }
save_equipment($rec['id'], valid(['room' => '305', 'status' => 'repair']), (int) $rec['version']);
$upd = find_equipment($rec['id']);
check('T6 версия увеличилась', $upd['version'] === 2);
check('T6 журнал содержит перемещение и статус', count($upd['history']) === 3);
$conflict = false;
try { save_equipment($rec['id'], valid(), 1); } catch (ConflictException) { $conflict = true; }
check('T6 устаревшая версия -> конфликт', $conflict);

// T7 фильтры и сводка
check('T7 фильтр по статусу', count(filter_equipment(load_equipment(), 'repair', '', '')) === 2);
check('T7 поиск без учёта регистра', count(filter_equipment(load_equipment(), '', '', 'pc-100')) === 1);
check('T7 пустой результат', filter_equipment(load_equipment(), '', 'printer', '') === []);
check('T7 сводка total', summarize(load_equipment())['total'] === 5);

// T8 удаление
delete_equipment($rec['id']);
check('T8 запись удалена', find_equipment($rec['id']) === null);

// T9 повреждённый JSON
file_put_contents(data_file(), '{broken');
$broken = false;
try { load_equipment(); } catch (AppException) { $broken = true; }
check('T9 повреждённый JSON -> контролируемая ошибка', $broken);

// T10 недоступный каталог
putenv('EQUIPMENT_DATA_FILE=/nonexistent_dir_xyz/equipment.json');
$unavail = false;
try { save_equipment(null, valid()); } catch (AppException) { $unavail = true; }
check('T10 недоступный каталог -> контролируемая ошибка', $unavail);

// T11 экранирование
check('T11 e() экранирует HTML', e('<b>"x"</b>') === '&lt;b&gt;&quot;x&quot;&lt;/b&gt;');

echo "\nИтого: $passed passed, $failed failed\n";
exit($failed === 0 ? 0 : 1);
