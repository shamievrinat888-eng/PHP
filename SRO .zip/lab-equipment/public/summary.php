<?php
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';

try {
    $summary = summarize(load_equipment());
} catch (AppException $ex) {
    render_page('error', ['message' => $ex->getMessage()], 'Ошибка');
    exit;
}
render_page('summary', compact('summary'), 'Сводка по состояниям');
