<?php
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';

// Удаление — только POST + CSRF, затем Post/Redirect/Get.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    try {
        delete_equipment(str_param($_POST, 'id'));
        flash('success', 'Запись удалена.');
    } catch (AppException $ex) {
        flash('error', $ex->getMessage());
    }
    redirect('index.php');
}

$status = str_param($_GET, 'status');
$type = str_param($_GET, 'type');
$q = mb_substr(str_param($_GET, 'q'), 0, 50);
if (!array_key_exists($status, EQUIPMENT_STATUSES)) { $status = ''; }
if (!array_key_exists($type, EQUIPMENT_TYPES)) { $type = ''; }

try {
    $all = load_equipment();
    $items = filter_equipment($all, $status, $type, $q);
    $summary = summarize($all);
    $error = null;
} catch (AppException $ex) {
    $items = []; $summary = null; $error = $ex->getMessage();
}

render_page('index', compact('items', 'summary', 'error', 'status', 'type', 'q'), 'Реестр оборудования');
