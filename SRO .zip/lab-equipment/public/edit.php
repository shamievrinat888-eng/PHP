<?php
declare(strict_types=1);
require __DIR__ . '/../src/bootstrap.php';

$id = str_param($_GET, 'id');
$id = $id === '' ? null : $id;
$errors = [];
$data = ['inventory' => '', 'type' => 'computer', 'room' => '', 'status' => 'working', 'note' => ''];
$version = 0;
$history = [];

try {
    if ($id !== null) {
        $existing = find_equipment($id);
        if ($existing === null) {
            http_response_code(404);
            render_page('error', ['message' => 'Запись не найдена.'], 'Не найдено');
            exit;
        }
        $data = array_intersect_key($existing, $data);
        $version = (int) $existing['version'];
        $history = $existing['history'] ?? [];
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require_csrf();
        $data = normalize_input($_POST);
        $version = (int) str_param($_POST, 'version');
        $errors = validate_equipment($data);
        if ($errors === []) {
            try {
                save_equipment($id, $data, $version);
                flash('success', $id === null ? 'Оборудование добавлено.' : 'Изменения сохранены.');
                redirect('index.php');
            } catch (ValidationException $ex) {
                $errors = $ex->errors;
            } catch (ConflictException $ex) {
                flash('error', $ex->getMessage());
                redirect($id === null ? 'edit.php' : 'edit.php?id=' . rawurlencode($id));
            }
        }
    }
} catch (AppException $ex) {
    render_page('error', ['message' => $ex->getMessage()], 'Ошибка');
    exit;
}

render_page('edit', compact('id', 'data', 'errors', 'version', 'history'),
    $id === null ? 'Добавить оборудование' : 'Редактировать оборудование');
