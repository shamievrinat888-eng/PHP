<?php
declare(strict_types=1);

const EQUIPMENT_TYPES = [
    'computer' => 'Компьютер', 'monitor' => 'Монитор', 'projector' => 'Проектор',
    'printer' => 'Принтер', 'network' => 'Сетевое оборудование', 'other' => 'Другое',
];
const EQUIPMENT_STATUSES = [
    'working' => 'Исправно', 'repair' => 'В ремонте',
    'storage' => 'На складе', 'written_off' => 'Списано',
];

/**
 * Нормализация: только строки, trim, схлопывание пробелов, инвентарный номер в верхний регистр.
 * Нестроковые значения (например, массивы) превращаются в пустую строку.
 * @param array<string,mixed> $post
 * @return array{inventory:string,type:string,room:string,status:string,note:string}
 */
function normalize_input(array $post): array
{
    $clean = static function (string $key) use ($post): string {
        $v = $post[$key] ?? '';
        if (!is_string($v)) {
            return '';
        }
        return trim((string) preg_replace('/\s+/u', ' ', $v));
    };
    return [
        'inventory' => mb_strtoupper($clean('inventory')),
        'type' => $clean('type'),
        'room' => $clean('room'),
        'status' => $clean('status'),
        'note' => $clean('note'),
    ];
}

/**
 * @param array{inventory:string,type:string,room:string,status:string,note:string} $d
 * @return array<string,string>
 */
function validate_equipment(array $d): array
{
    $errors = [];
    if ($d['inventory'] === '') {
        $errors['inventory'] = 'Укажите инвентарный номер.';
    } elseif (!preg_match('/^[A-Z0-9][A-Z0-9\-]{2,19}$/', $d['inventory'])) {
        $errors['inventory'] = 'Номер: 3–20 символов, латиница, цифры и дефис.';
    }
    if (!array_key_exists($d['type'], EQUIPMENT_TYPES)) {
        $errors['type'] = 'Выберите тип из списка.';
    }
    if ($d['room'] === '') {
        $errors['room'] = 'Укажите аудиторию.';
    } elseif (!preg_match('/^[\p{L}0-9\-\/ ]{1,20}$/u', $d['room'])) {
        $errors['room'] = 'Аудитория: до 20 символов (буквы, цифры, дефис, /).';
    }
    if (!array_key_exists($d['status'], EQUIPMENT_STATUSES)) {
        $errors['status'] = 'Выберите статус из списка.';
    }
    if (mb_strlen($d['note']) > 200) {
        $errors['note'] = 'Примечание не длиннее 200 символов.';
    }
    return $errors;
}
