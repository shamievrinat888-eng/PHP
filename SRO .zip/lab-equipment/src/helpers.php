<?php
declare(strict_types=1);

class AppException extends RuntimeException {}
class ConflictException extends AppException {}
class ValidationException extends AppException
{
    /** @param array<string,string> $errors */
    public function __construct(public readonly array $errors)
    {
        parent::__construct('Ошибка валидации');
    }
}

function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): never
{
    header('Location: ' . $url, true, 303);
    exit;
}

function csrf_token(): string
{
    if (!isset($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function require_csrf(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(403);
        render_page('error', ['message' => 'Недействительный CSRF-токен. Обновите страницу и повторите действие.'], 'Доступ запрещён');
        exit;
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

/** @return list<array{type:string,message:string}> */
function take_flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return is_array($items) ? array_values($items) : [];
}

/** @param array<string,mixed> $vars */
function render_page(string $template, array $vars, string $title): void
{
    extract($vars, EXTR_SKIP);
    ob_start();
    require dirname(__DIR__) . '/templates/' . $template . '.php';
    $content = ob_get_clean();
    require dirname(__DIR__) . '/templates/layout.php';
}

/** Значение параметра только если это строка (иначе пустая строка). */
function str_param(array $source, string $key): string
{
    $v = $source[$key] ?? '';
    return is_string($v) ? trim($v) : '';
}
