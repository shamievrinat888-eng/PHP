<?php
declare(strict_types=1);

function data_file(): string
{
    $env = getenv('EQUIPMENT_DATA_FILE');
    return is_string($env) && $env !== '' ? $env : dirname(__DIR__) . '/var/data/equipment.json';
}

/** @return list<array<string,mixed>> */
function seed_data(): array
{
    $now = date('Y-m-d H:i:s');
    $mk = static fn(string $id, string $inv, string $type, string $room, string $status, string $note): array => [
        'id' => $id, 'inventory' => $inv, 'type' => $type, 'room' => $room,
        'status' => $status, 'note' => $note, 'version' => 1, 'created_at' => $now,
        'history' => [['at' => $now, 'event' => 'Создано']],
    ];
    return [
        $mk('eq_seed0001', 'PC-0001', 'computer', '301', 'working', 'Рабочая станция №1'),
        $mk('eq_seed0002', 'PC-0002', 'computer', '301', 'repair', 'Не включается блок питания'),
        $mk('eq_seed0003', 'MON-0001', 'monitor', '302', 'working', ''),
        $mk('eq_seed0004', 'PRJ-0001', 'projector', '305', 'storage', 'На складе'),
    ];
}

/** @return list<array<string,mixed>> */
function load_equipment(): array
{
    $file = data_file();
    if (!is_file($file)) {
        return seed_data();
    }
    $raw = @file_get_contents($file);
    if ($raw === false) {
        throw new AppException('Хранилище данных недоступно.');
    }
    try {
        $data = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new AppException('Файл данных повреждён. Обратитесь к администратору.');
    }
    if (!is_array($data)) {
        throw new AppException('Файл данных имеет неверный формат.');
    }
    return array_values($data);
}

/**
 * Читает, изменяет и атомарно записывает данные под эксклюзивной блокировкой.
 * @param callable(list<array<string,mixed>>):list<array<string,mixed>> $fn
 */
function mutate_equipment(callable $fn): void
{
    $file = data_file();
    $dir = dirname($file);
    if (!is_dir($dir) || !is_writable($dir)) {
        throw new AppException('Каталог данных недоступен для записи.');
    }
    $lock = fopen($file . '.lock', 'c');
    if ($lock === false || !flock($lock, LOCK_EX)) {
        throw new AppException('Не удалось получить блокировку хранилища.');
    }
    try {
        $items = $fn(load_equipment());
        $json = json_encode($items, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $tmp = $file . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (file_put_contents($tmp, $json) === false || !rename($tmp, $file)) {
            @unlink($tmp);
            throw new AppException('Не удалось сохранить данные.');
        }
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}
