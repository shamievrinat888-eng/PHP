<?php
declare(strict_types=1);

/**
 * @param list<array<string,mixed>> $items
 * @return list<array<string,mixed>>
 */
function filter_equipment(array $items, string $status, string $type, string $query): array
{
    $query = mb_strtolower($query);
    $out = array_filter($items, static function (array $it) use ($status, $type, $query): bool {
        if ($status !== '' && $it['status'] !== $status) {
            return false;
        }
        if ($type !== '' && $it['type'] !== $type) {
            return false;
        }
        if ($query !== '') {
            $hay = mb_strtolower($it['inventory'] . ' ' . $it['room'] . ' ' . $it['note']);
            if (!str_contains($hay, $query)) {
                return false;
            }
        }
        return true;
    });
    $out = array_values($out);
    usort($out, static fn(array $a, array $b): int => strcmp((string) $a['inventory'], (string) $b['inventory']));
    return $out;
}

/**
 * @param list<array<string,mixed>> $items
 * @return array{total:int,by_status:array<string,int>,by_type:array<string,int>,by_room:array<string,int>}
 */
function summarize(array $items): array
{
    $byStatus = array_fill_keys(array_keys(EQUIPMENT_STATUSES), 0);
    $byType = array_fill_keys(array_keys(EQUIPMENT_TYPES), 0);
    $byRoom = [];
    foreach ($items as $it) {
        $byStatus[$it['status']] = ($byStatus[$it['status']] ?? 0) + 1;
        $byType[$it['type']] = ($byType[$it['type']] ?? 0) + 1;
        $byRoom[$it['room']] = ($byRoom[$it['room']] ?? 0) + 1;
    }
    ksort($byRoom);
    return ['total' => count($items), 'by_status' => $byStatus, 'by_type' => $byType, 'by_room' => $byRoom];
}

/** @return array<string,mixed>|null */
function find_equipment(string $id): ?array
{
    foreach (load_equipment() as $it) {
        if ($it['id'] === $id) {
            return $it;
        }
    }
    return null;
}

/**
 * Создаёт ($id === null) или обновляет запись. Уникальность и версия проверяются под блокировкой.
 * @param array{inventory:string,type:string,room:string,status:string,note:string} $d
 */
function save_equipment(?string $id, array $d, int $version = 0): void
{
    mutate_equipment(static function (array $items) use ($id, $d, $version): array {
        foreach ($items as $it) {
            if ($it['inventory'] === $d['inventory'] && $it['id'] !== $id) {
                throw new ValidationException(['inventory' => 'Такой инвентарный номер уже существует.']);
            }
        }
        $now = date('Y-m-d H:i:s');
        if ($id === null) {
            $items[] = $d + [
                'id' => 'eq_' . bin2hex(random_bytes(6)),
                'version' => 1, 'created_at' => $now,
                'history' => [['at' => $now, 'event' => 'Создано']],
            ];
            return $items;
        }
        foreach ($items as $i => $it) {
            if ($it['id'] !== $id) {
                continue;
            }
            if ((int) $it['version'] !== $version) {
                throw new ConflictException('Запись была изменена другим пользователем. Откройте её заново.');
            }
            $events = [];
            if ($it['room'] !== $d['room']) {
                $events[] = ['at' => $now, 'event' => "Перемещено: {$it['room']} → {$d['room']}"];
            }
            if ($it['status'] !== $d['status']) {
                $events[] = ['at' => $now, 'event' => 'Статус: ' . EQUIPMENT_STATUSES[$it['status']]
                    . ' → ' . EQUIPMENT_STATUSES[$d['status']]];
            }
            $items[$i] = $d + [
                'id' => $it['id'], 'created_at' => $it['created_at'],
                'version' => (int) $it['version'] + 1,
                'history' => array_merge($it['history'] ?? [], $events),
            ];
            return $items;
        }
        throw new AppException('Запись не найдена.');
    });
}

function delete_equipment(string $id): void
{
    mutate_equipment(static function (array $items) use ($id): array {
        $new = array_values(array_filter($items, static fn(array $it): bool => $it['id'] !== $id));
        if (count($new) === count($items)) {
            throw new AppException('Запись не найдена.');
        }
        return $new;
    });
}
