<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Almaty');
mb_internal_encoding('UTF-8');

// Технические детали ошибок не показываем пользователю.
ini_set('display_errors', '0');
ini_set('log_errors', '1');

require __DIR__ . '/helpers.php';
require __DIR__ . '/storage.php';
require __DIR__ . '/validation.php';
require __DIR__ . '/equipment.php';

if (PHP_SAPI !== 'cli') {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    set_exception_handler(static function (Throwable $e): void {
        error_log($e->getMessage());
        http_response_code(500);
        render_page('error', ['message' => 'Внутренняя ошибка приложения. Попробуйте позже.'], 'Ошибка');
    });
}
